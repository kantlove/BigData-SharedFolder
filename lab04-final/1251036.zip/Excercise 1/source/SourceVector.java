package vector_matrix_mul;

import java.util.ArrayList;

public class SourceVector {
	public static ArrayList<Integer> vector = new ArrayList<Integer>();
	
	public SourceVector() {
		
	}
}
